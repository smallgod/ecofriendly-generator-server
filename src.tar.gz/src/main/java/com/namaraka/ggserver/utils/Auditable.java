/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.namaraka.ggserver.utils;

/**
 *
 * @author smallgod
 */
public interface Auditable extends DBMSXMLObject{
    String getUsername();
}
