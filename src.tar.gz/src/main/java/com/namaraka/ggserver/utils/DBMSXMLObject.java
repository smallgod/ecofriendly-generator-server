package com.namaraka.ggserver.utils;

/**
 * all JAVA object representations of XML will implement this interface
 *
 * @author smallGod
 */
public interface DBMSXMLObject {
    public DBMSXMLObject getXMLObject();    
}